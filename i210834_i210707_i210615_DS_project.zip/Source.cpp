#include<iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include"../DS_PROJECT/\RB-TREE.h"
#include"../DS_PROJECT/AVL TREE.h"
#include"../DS_PROJECT/stack.h"
using namespace std;

int main()
{
    stack<string> st;

  
    st.push("NCHS_-_Leading_Causes_of_Death__United_States_10.csv");
    st.push("NCHS_-_Leading_Causes_of_Death__United_States_9.csv");
    st.push("NCHS_-_Leading_Causes_of_Death__United_States_8.csv");
    st.push("NCHS_-_Leading_Causes_of_Death__United_States_7.csv");
    st.push("NCHS_-_Leading_Causes_of_Death__United_States_6.csv");
    st.push("NCHS_-_Leading_Causes_of_Death__United_States_5.csv");
    st.push("NCHS_-_Leading_Causes_of_Death__United_States_4.csv");
    st.push("NCHS_-_Leading_Causes_of_Death__United_States_3.csv");
    st.push("NCHS_-_Leading_Causes_of_Death__United_States_2.csv");
    st.push("NCHS_-_Leading_Causes_of_Death__United_States_1.csv");
    int y;
    RBTree bst;
    AVL avl;
    int chi;
    int ch;
    int id;
    char choice = 0;
    bool  newuseravl = false;
    char chn;

    string a;
    string b;
    string c;
    int d, e;
    int i = 1;
    
    bool new_user = false;

    char chh;
    int cho;

 do {

     system("CLS");
     cout << "------------------------------------------------------------------------------------------------------------------------\n";
     cout << "------------------------------------------------------------------------------------------------------------------------\n\n";
     cout << "\t\t\t\t\t\tSELECT THE TREE\n\n";
     cout << "------------------------------------------------------------------------------------------------------------------------\n";
     cout << "------------------------------------------------------------------------------------------------------------------------\n";
     cout << "1) AVL\n";
     cout << "2) RED/BLACK\n";
     cout << "3) B-TREES\n";
     cout << "ENTER YOUR CHOICE : ";
     cin >> cho;

     if (cho == 2)
     {

         do
         {
             system("CLS");
             cout << "------------------------------------------------------------------------------------------------------------------------\n";
             cout << "------------------------------------------------------------------------------------------------------------------------\n\n";
             cout << "\t\t\t\t\t\tWELCOME TO DATA BASE\n\n";
             cout << "------------------------------------------------------------------------------------------------------------------------\n";
             cout << "------------------------------------------------------------------------------------------------------------------------\n";
             cout << "1) INDEXING\n";
             cout << "2) SEARCHING\n";
             cout << "3) UPDATE\n";
             cout << "4) DELETE\n";
             cout << "5) RANGE SEARCH\n";
             cout << "6) PRINT TREE\n";
             cout << "ENTER YOUR CHOICE : ";
             cin >> ch;


             if (ch == 1)
             {

                 
                     new_user = true;
                     while (!st.isempty())
                     {
                         string fname = st.top->val;
                         st.pop();

                         vector<vector<string>> content;
                         vector<string> row;
                         string line, word;

                         fstream file(fname, ios::in);
                         if (file.is_open())
                         {
                             while (getline(file, line))
                             {
                                 row.clear();

                                 stringstream str(line);

                                 while (getline(str, word, ','))
                                     row.push_back(word);
                                 content.push_back(row);
                             }
                         }
                         else
                             cout << "Could not open the file\n";

                         for (int i = 1; i < content.size(); i++)
                         {
                             y = stoi(content[i][0]);
                             bst.insert(y, i, fname);
                         }
                     }
                     bst.create_files();
                 
                 
             }


             else if (ch == 2)
             {

                 cout << "Enter The ID You Want To Search For.\n";
                 cin >> id;
                 cout << endl;

                 string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\nodes\\node-";
                 ifstream file;
                 file.open(n + to_string(id) + ".txt");
                 getline(file, a);
                 file.close();
                 if (a != "0")
                 {
                     if (!new_user)
                         bst.createtree(bst);
                     bst.searchTree(id);
                 }
                 else
                     cout << "ID DOES NOT EXIST\n";

             }
             else if (ch == 3)
             {

                 cout << "Enter The ID You Want To Update.\n";
                 cin >> id;
                 cout << endl;

             }
             else if (ch == 4)
             {
                 cout << "Enter The ID You Want To Delete For.\n";
                 cin >> id;
                 cout << endl;

                 bool f = false;

                 string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\nodes\\node-";
                 ifstream file;
                 if (!new_user)
                     bst.createtree(bst);

                 file.open(n + to_string(id) + ".txt");
                 getline(file, a);
                 file.close();
                 if (a != "0")
                 {

                     //bst.deletefile(id);
                     f = bst.deleteNode(id);
                     bst.create_files();
                 }
             }
             else if (ch == 5)
             {
                 int idn;
                 cout << "Enter The ID You Want To Search For.\n";
                 cout << "ENTER STARTING ID : ";
                 cin >> id;

                 cout << "Enter The ID You Want To Search For.\n";
                 cout << "ENTER ENDING ID : ";
                 cin >> idn;

                 string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\nodes\\node-";
                 ifstream file;
                 if (!new_user)
                     bst.createtree(bst);

                 for (int i = id; i <= idn; i++)
                 {
                     file.open(n + to_string(i) + ".txt");
                     getline(file, a);
                     file.close();
                     if (a != "0")
                     {
                         bst.searchTree(i);
                     }
                     else
                     {
                         cout << "ID : " << i << " DOES NOT EXIST\n";
                     }

                 }
             }
             else if (ch == 6)
             {
                 if (!new_user)
                 {
                     bst = bst.createtree(bst);
                 }
                 bst.prettyPrint();
             }
             else
             {
                 cout << "INVALID ENTRY.\n\n";
             }

             cout << "DO YOU WANT TO PERFORM MORE FUNCTION'S ?\n";
             cin >> choice;

         } while (choice == 'y' || choice == 'Y');
     }
     else if (cho == 1)
     {
     do
     {
         system("CLS");
         cout << "------------------------------------------------------------------------------------------------------------------------\n";
         cout << "------------------------------------------------------------------------------------------------------------------------\n\n";
         cout << "\t\t\t\t\t\tWELCOME TO DATA BASE\n\n";
         cout << "------------------------------------------------------------------------------------------------------------------------\n";
         cout << "------------------------------------------------------------------------------------------------------------------------\n";
         cout << "1) INDEXING\n";
         cout << "2) SEARCHING\n";
         cout << "3) UPDATE\n";
         cout << "4) DELETE\n";
         cout << "5) RANGE SEARCH\n";
         cout << "6) PRINT TREE\n";
         cout << "ENTER YOUR CHOICE : ";
         cin >> chi;


         if (chi == 1)
         {
             int indexing;
             cout << "1) ID" << endl;
             cout << "2) YEAR" << endl;
             cout << "ENTER YOUR CHOICE : ";
             cin >> indexing;

             if (indexing == 1)
             {
                 newuseravl = true;

                 while (!st.isempty())
                 {
                     string fname = st.top->val;
                     st.pop();

                     vector<vector<string>> content;
                     vector<string> row;
                     string line, word;

                     fstream file(fname, ios::in);
                     if (file.is_open())
                     {
                         while (getline(file, line))
                         {
                             row.clear();

                             stringstream str(line);

                             while (getline(str, word, ','))
                                 row.push_back(word);
                             content.push_back(row);
                         }
                     }
                     else
                         cout << "Could not open the file\n";

                     for (int i = 1; i < content.size(); i++)
                     {
                         y = stoi(content[i][0]);
                         avl.root = avl.insert(y, avl.root, i, fname);
                     }

                 }

                 avl.create_filesavl("C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\AVLnodes\\node-");
             }
             else if (indexing == 2)
             {
                 newuseravl = true;
             
                 while (!st.isempty())
                 {
                     string fname = st.top->val;
                     st.pop();
             
                     vector<vector<string>> content;
                     vector<string> row;
                     string line, word;
             
                     fstream file(fname, ios::in);
                     if (file.is_open())
                     {
                         while (getline(file, line))
                         {
                             row.clear();
             
                             stringstream str(line);
             
                             while (getline(str, word, ','))
                                 row.push_back(word);
                             content.push_back(row);
                         }
                     }
                     else
                         cout << "Could not open the file\n";
             
                     for (int i = 1; i < content.size(); i++)
                     {
                         y = stoi(content[i][1]);
                         avl.root = avl.insert(y, avl.root, i + 1, fname);
                     }
             
                 }
                 avl.create_filesavlyear("C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\AVLNODES_YEAR\\node-");
             }
         }

         if (chi == 2)
         {
                  int s;
                cout << "SEARCH ON BASIS OF:" << endl;
                 cout << "      1) ID" << endl;
                 cout << "      2) YEAR" << endl;
                 cin >> s;

                 if (s == 1)
                 {
                     int i;
                     cout << "Enter The ID You Want To Search For.\n";
                     cin >> i;
                     cout << endl;

                     string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\AVLnodes\\node-";
                     ifstream file;
                     file.open(n + to_string(i) + ".txt");
                     getline(file, a);
                     file.close();
                     if (a != "0")
                     {
                         if(!newuseravl)
                              avl.createtrees(avl);
                         avl.searchTrees( i);
                     }
                     else
                         cout << "ID DOES NOT EXIST\n";

                 }
                 else if (s == 2)
                 {
                     int idd;
                     cout << "Enter The ID You Want To Search:\n";
                     cin >> idd;
                     cout << endl;
                 
                 
                 
                     string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\AVLNODES_YEAR\\node-";
                     ifstream file;
                     file.open(n + to_string(idd) + ".txt");
                     getline(file, a);
                     file.close();
                     if (a != "0")
                     {
                        
                             avl.createtreeavlyear(avl,idd);
                         avl.searchyear(avl.root,idd);
                     }
                     else
                         cout << "ID DOES NOT EXIST\n";
                 }
         }
         else if (chi == 3)
         {

             cout << "Enter The ID You Want To Update.\n";
             cin >> id;
             cout << endl;

         }
         else if (chi == 4)
         {
             int del;

             cout << "WHAT WOULD YOU LIKE TO DELETE:";
             cout << "          1) ID " << endl;
             cout << "          2) YEAR " << endl;
             cin >> del;

             string n;
             if (del == 1)
             {

                 cout << "Enter The ID You Want To Delete:\n";
                 cin >> id;
                 cout << endl;
                 n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\AVLnodes\\node-";
                 bool f = false;

                 ifstream file;
                 if (!newuseravl)
                     avl.createtreeavl(avl,n);

                 file.open(n + to_string(id) + ".txt");
                 getline(file, a);
                 file.close();
                 if (a != "0")
                 {

                     //bst.deletefile(id);
                     f = avl.deleteNodeavl(avl.root, id, n);
                     avl.create_filesavl(n);
                 }

             }

             else if (del == 2)
             {
                 cout << "Enter The Year You Want To Delete:\n";
                 cin >> id;
                 cout << endl;
                 n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\AVLNODES_YEAR\\node-";
                 bool f = false;

                 ifstream file;
                 if (!newuseravl)
                     avl.createtreeavl(avl,n);

                 file.open(n + to_string(id) + ".txt");
                 getline(file, a);
                 file.close();
                 if (a != "0")
                 {

                     //bst.deletefile(id);
                     f = avl.deleteNodeavl(avl.root, id, n);
                     avl.create_filesavlyear(n);
                 }
             }

                
            
         }

         else if (chi == 5)
         {
         
             int ids;
             int idn;
             cout << "Enter The ID You Want To Search For.\n";
             cout << "ENTER STARTING ID : ";
             cin >> ids;

             cout << "Enter The ID You Want To Search For.\n";
             cout << "ENTER ENDING ID : ";
             cin >> idn;

             string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\AVLnodes\\node-";
             ifstream file;
             if (!newuseravl)
                 avl.createtreeavl(avl,n);

             for (int i = ids; i <= idn; i++)
             {

                 file.open(n + to_string(i) + ".txt");
                 getline(file, a);
                 file.close();
                 if (a != "0")
                 {
                     //avl.searchTreeavl(i);
                 }
                 else
                 {
                     cout << "ID : " << i << " DOES NOT EXIST\n";
                 }

             }
         

         }
         else if (chi == 6)
         {
         int p;
         cout << "PRINT TREE ON BASIS OF:" << endl;
         cout << "     1) ID" << endl;
         cout << "     2) YEAR" << endl;
         cin >> p;
         string n;

         if (p == 1)
         {
             n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\AVLnodes\\node-";
         }
         else if (p == 2)
         {
             n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\AVLNODES_YEAR\\node-";
         }

             if (!newuseravl)
             {
                 avl = avl.createtreeavl(avl,n);
             }
             avl.prettyPrintavl();
         }

         else if(chi>6)
         {
             cout << "INVALID ENTRY.\n\n";
         }

         cout << "DO YOU WANT TO PERFORM MORE FUNCTION'S ?\n";
         cin >> chn;
         

     }while (chn == 'y' || chn == 'Y');

     }

    cout << "DO YOU WANT TO SELECT ANY OTHER TREE ?\n";
    cin >> chh;

    }while (chh == 'y' || chh == 'Y');

    return 0;
}