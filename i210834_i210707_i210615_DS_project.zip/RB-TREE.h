#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
using namespace std;

template<class t>

class Node
{
public:
	t data;
	Node* parent;
	Node* left;
	Node* right;
	int color;
	int line;
	string file;

	Node()
	{
		data = 0;
		parent = NULL;
		left = NULL;
		right = NULL;
		color = 0;
		line = 0;
		file = "";
	}
};

typedef Node<int>* NodePtr;

class RBTree
{
public:
	NodePtr root;
	NodePtr TNULL;

	RBTree() {
		TNULL = new Node<int>;
		TNULL->color = 0;
		TNULL->left = nullptr;
		TNULL->right = nullptr;
		root = TNULL;
		TNULL->line = 0;
	}

	//-------------------------------------INSERTION---------------------------------

	void insert(int key, int l, string fnmae) {
		NodePtr node = new Node<int>;
		node->parent = nullptr;
		node->data = key;
		node->left = TNULL;
		node->right = TNULL;
		node->color = 1;
		node->line = (l + 1);
		node->file = fnmae;
		Node<int>* u;
		NodePtr y = nullptr;
		NodePtr x = this->root;

		while (x != TNULL) {
			y = x;
			if (node->data < x->data) {
				x = x->left;
			}
			else {
				x = x->right;
			}
		}

		// y is parent of x
		node->parent = y;
		if (y == nullptr) {
			root = node;
		}
		else if (node->data < y->data) {
			y->left = node;
		}
		else {
			y->right = node;
		}

		// if new node is a root node, simply return
		if (node->parent == nullptr) {
			node->color = 0;
			return;
		}

		// if the grandparent is null, simply return
		if (node->parent->parent == nullptr) {
			return;
		}

		// Fix the tree

		while (node->parent->color == 1) {
			if (node->parent == node->parent->parent->right) {
				u = node->parent->parent->left;
				if (u->color == 1) {
					u->color = 0;
					node->parent->color = 0;
					node->parent->parent->color = 1;
					node = node->parent->parent;
				}
				else {
					if (node == node->parent->left) {
						node = node->parent;
						rightRotate(node);
					}
					node->parent->color = 0;
					node->parent->parent->color = 1;
					leftRotate(node->parent->parent);
				}
			}
			else {
				u = node->parent->parent->right;

				if (u->color == 1) {
					u->color = 0;
					node->parent->color = 0;
					node->parent->parent->color = 1;
					node = node->parent->parent;
				}
				else {
					if (node == node->parent->right) {
						// mirror case 3.2.2
						node = node->parent;
						leftRotate(node);
					}
					// mirror case 3.2.1
					node->parent->color = 0;
					node->parent->parent->color = 1;
					rightRotate(node->parent->parent);
				}
			}
			if (node == root) {
				break;
			}
		}
		root->color = 0;
	}



	Node<int>* searchTreeHelper(Node<int>* node, int key) {
		if (node == NULL)
			return node;
		if (key == node->data)
			return node;

		if (key < node->data)
			return searchTreeHelper(node->left, key);
		else if (key > node->data)
			return searchTreeHelper(node->right, key);
	}

	void fixDelete(Node<int>* x) {
		Node<int>* s;
		while (x != root && x->color == 0) {
			if (x == x->parent->left) {
				s = x->parent->right;
				if (s->color == 1) {
					// case 3.1
					s->color = 0;
					x->parent->color = 1;
					leftRotate(x->parent);
					s = x->parent->right;
				}

				if (s->left->color == 0 && s->right->color == 0) {
					// case 3.2
					s->color = 1;
					x = x->parent;
				}
				else {
					if (s->right->color == 0) {
						// case 3.3
						s->left->color = 0;
						s->color = 1;
						rightRotate(s);
						s = x->parent->right;
					}

					// case 3.4
					s->color = x->parent->color;
					x->parent->color = 0;
					s->right->color = 0;
					leftRotate(x->parent);
					x = root;
				}
			}
			else {
				s = x->parent->left;
				if (s->color == 1) {
					// case 3.1
					s->color = 0;
					x->parent->color = 1;
					rightRotate(x->parent);
					s = x->parent->left;
				}

				if (s->right->color == 0 && s->right->color == 0) {
					// case 3.2
					s->color = 1;
					x = x->parent;
				}
				else {
					if (s->left->color == 0) {
						// case 3.3
						s->right->color = 0;
						s->color = 1;
						leftRotate(s);
						s = x->parent->left;
					}

					// case 3.4
					s->color = x->parent->color;
					x->parent->color = 0;
					s->left->color = 0;
					rightRotate(x->parent);
					x = root;
				}
			}
		}
		x->color = 0;
	}


	void rbTransplant(Node<int>* u, Node<int>* v) {
		if (u->parent == NULL) {
			root = v;
		}
		else if (u == u->parent->left) {
			u->parent->left = v;
		}
		else {
			u->parent->right = v;
		}
		v->parent = u->parent;
	}

	void deleteNodeHelper(Node<int>* node, int key) {
		// find the node containing key
		
		NodePtr z = TNULL;
		NodePtr x, y;
		while (node != TNULL) {
			if (node->data == key) {
				z = node;
			}

			if (node->data <= key) {
				node = node->right;
			}
			else {
				node = node->left;
			}
		}

		if (z == TNULL) {
			cout << "Couldn't find key in the tree" << endl;
			return;
		}

		y = z;
		int y_original_color = y->color;
		if (z->left == TNULL) {
			x = z->right;
			rbTransplant(z, z->right);
		}
		else if (z->right == TNULL) {
			x = z->left;
			rbTransplant(z, z->left);
		}
		else {
			y = minimum(z->right);
			y_original_color = y->color;
			x = y->right;
			if (y->parent == z) {
				x->parent = y;
			}
			else {
				rbTransplant(y, y->right);
				y->right = z->right;
				y->right->parent = y;
			}

			rbTransplant(z, y);
			y->left = z->left;
			y->left->parent = y;
			y->color = z->color;
		}
		delete z;
		if (y_original_color == 0) {
			fixDelete(x);
		}


		string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\nodes\\node-";
		ofstream MyFile(n + to_string(key) + ".txt");
		MyFile << 0 << endl;
		MyFile.close();
	}


	void printHelper(Node<int>* root, string indent, bool last)
	{

		if (root != TNULL) {
			cout << indent;
			if (last) {
				cout << "R----";
				indent += "     ";
			}
			else {
				cout << "L----";
				indent += "|    ";
			}

			string sColor = root->color ? "RED" : "BLACK";
			cout << root->data << "(" << sColor << ")" << endl;
			printHelper(root->left, indent, false);
			printHelper(root->right, indent, true);
		}
	}

	////////////////////////////////////////////////////////////
	void createfiles(Node<int>* root, bool last)
	{
		string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\nodes\\node-";
		ofstream MyFile(n + to_string(root->data) + ".txt");
		MyFile << root->data << endl;
		MyFile << root->file << endl;
		MyFile << root->line << endl;
		if (root->left != NULL)
			MyFile << n + to_string(root->left->data) << endl;
		if (root->right != NULL)
			MyFile << n + to_string(root->right->data) << endl;
		MyFile.close();
		if (root != TNULL) {
			createfiles(root->left, false);
			createfiles(root->right, true);
		}
	}
	/////////////////////////////////////////////////////////////

	void searchTree(int k) 
	{
		Node<int>* n;
		n= searchTreeHelper(this->root, k);
		display_node(n->data);
	}

	Node<int>* minimum(Node<int>* node) {
		while (node->left != TNULL)
		{
			node = node->left;
		}
		return node;
	}

	Node<int>* maximum(Node<int>* node) {
		while (node->right != TNULL) {
			node = node->right;
		}
		return node;
	}
	

	RBTree createtree(RBTree& bst)
	{

		string a;
		string b;
		string c;
		int d, e;
		int i = 1;
	 string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\nodes\\node-";
	 ifstream file;
	 
	 do
	 {
	     file.open(n + to_string(i) + ".txt");
	     getline(file , a);
	     d = stoi(a);
	 
	     if (d != 0)
	     {
	         getline(file, c);
	         getline(file, b);
	        
	        e = stoi(b);
	 
	        bst.insert(d, e , c);
	       
	     }
	 
	    // tree.root = tree.insert(tree.root, a, b, name);
	     file.close();
	     i++;
	 } while (i<11000);
	 return bst;

	}


	void leftRotate(Node<int>* x) {
		Node<int>* y = x->right;
		x->right = y->left;
		if (y->left != TNULL) {
			y->left->parent = x;
		}
		y->parent = x->parent;
		if (x->parent == nullptr) {
			this->root = y;
		}
		else if (x == x->parent->left) {
			x->parent->left = y;
		}
		else {
			x->parent->right = y;
		}
		y->left = x;
		x->parent = y;
	}

	void rightRotate(Node<int>* x) {
		Node<int>* y = x->left;
		x->left = y->right;
		if (y->right != TNULL) {
			y->right->parent = x;
		}
		y->parent = x->parent;
		if (x->parent == nullptr) {
			this->root = y;
		}
		else if (x == x->parent->right) {
			x->parent->right = y;
		}
		else {
			x->parent->left = y;
		}
		y->right = x;
		x->parent = y;
	}

	// delete the node from the tree
	bool deleteNode(int data) 
	{
		string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\nodes\\node-";
		ifstream MyFile(n + to_string(data) + ".txt");
		string a;
		getline(MyFile, a);
		MyFile.close();
		if(a=="0")
		{
			cout << "ID DOESNOT EXIST\n";
			return false;
		}
		else
		{
			deleteNodeHelper(this->root, data);
			return true;
		}
	}

	// print the tree structure on the screen
	void prettyPrint() {
		if (root) {
			printHelper(this->root, "", true);
		}
	}

	void create_files()
	{
		if (root) {

			createfiles(this->root, true);
		}
	}




	void display_node(int data)
	{
		string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\nodes\\node-";
		ifstream MyFile(n + to_string(data) + ".txt");
	
		string a,b;
		getline(MyFile, b);
		getline(MyFile, a);
	
		vector<vector<string>> content;
		vector<string> row;
		string line, word;
	
		fstream file(a, ios::in);
		if (file.is_open())
		{
			while (getline(file, line))
			{
				row.clear();
	
				stringstream str(line);
	
				while (getline(str, word, ','))
					row.push_back(word);
				content.push_back(row);
			}
		}
		else
			cout << "Could not open the file\n";
		int line_no;
		getline(MyFile, b);
		line_no = stoi(b);
		line_no -= 1;
	
		cout << "\n------------------------------------------------------------------------\n";
		cout << "                                 ID : " << data <<"                             \n";
		cout << "------------------------------------------------------------------------\n\n";
		cout << "ID                         :" << content[line_no][0] << endl;
		cout << "YEAR                       :" << content[line_no][1] << endl;
		cout << "113 CAUSE NAME             :" << content[line_no][2] << endl;
		cout << "CAUSE NAME                 :" << content[line_no][3] << endl;
		cout << "STATE                      :" << content[line_no][4] << endl;
		cout << "DEATHS                     :" << content[line_no][5] << endl;
		cout << "AGE-ADJUSTED DEATH RATE    :" << content[line_no][6] << endl;
		cout << "\n------------------------------------------------------------------------\n\n";
	}
	//-------------------------------------------------------------------------------------
	
	

	//-------------------------------------------------------------------------------
	void deletefile(int id)
	{
		
		string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\nodes\\node-";
		ifstream MyFile(n + to_string(id) + ".txt");

		string a,b;
		getline(MyFile, b);
		getline(MyFile, a);
		getline(MyFile, b);
		MyFile.close();
		
		vector<vector<string>> content;
		vector<string> row;
		string line, word;

		ifstream file(a);
		if (file.is_open())
		{
			while (getline(file, line))
			{
				row.clear();

				stringstream str(line);

				while (getline(str, word, ','))
					row.push_back(word);
				content.push_back(row);
			}
		}
		else
			cout << "Could not open the file\n";
		int line_no;
		
		line_no = stoi(b);
		cout << line_no;

		int i = line_no;
		i = i - 1;

		while (i < content.size()-1)
		{	
			for (int j = 0; j < content[i].size(); j++)
			{
				content[i][j] = content[i+1][j];
			}
			i++;
		}


		for (int i = 1; i < content.size() - 1; i++)
		{

			write_files(a, content[i][0], content[i][1], content[i][2], content[i][3], content[i][4], content[i][5], content[i][6]);

		}

		remove("NCHS_-_Leading_Causes_of_Death__United_States_5.csv");

		// renaming the updated file with the existing file name
		//rename("new.csv", "NCHS_-_Leading_Causes_of_Death__United_States_5.csv");
	}


	void write_files(string file_name,string id ,string year,string cause_name_113,string cause_name,string state,string deaths,string age_adjusted_death_rate)
	{
			ofstream file;
			file.open("new.csv", ios::app);
			file << endl;
			file << id << "," << year << "," << cause_name_113 << "," << cause_name << "," << state << "," << deaths << "," << age_adjusted_death_rate<<"," ;
			file.close();
	}

};