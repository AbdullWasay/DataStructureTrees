#pragma once
#include<iostream>
using namespace std;


template<class T>

class node
{
public:
	T val;
	node<T>* next;

	node(T d)
	{
		val = d;
		next = NULL;
	}
	node()
	{
		val = '\0';
		next = NULL;
	}

};


template<class T>

class stack
{
public:

	node<T>* top;
	int size;

	stack()
	{
		top = NULL;
		size = 0;
	}
	void push(T d)
	{
		size++;
		node<T>* n = new node<T>(d);

		if (isempty())
		{
			top = n;
		}
		else
		{
			n->next = top;
			top = n;
		}
	}
	bool isempty()
	{
		if (top == NULL)
		{
			return true;
		}
		return false;
	}
	T pop()
	{
		if (!isempty())
		{
			node<T>* n = new node<T>;
			T a;

			size--;
			a = top->val;
			n = top->next;
			delete top;
			top = n;
			return a;
		}


	}

	node<T>* Peek()
	{
		return top;
	}
	int Size()
	{
		return size;
	}

};