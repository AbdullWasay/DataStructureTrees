#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include"LINKED LIST.h"
using namespace std;



class AvlNode {
public:
	int key;
	int height;
	AvlNode* left;
	AvlNode* right;
	int line;
	string file;
	SList* S;


	AvlNode()
	{
		key = 0;
		height = 0;
		left = NULL;
		right = NULL;
		line = 0;
		file = "";
		S = new SList();
	}

	AvlNode(int x)
	{
		key = x;
		height = 0;
		left = NULL;
		right = NULL;
		line = 0;
		file = "";
		S = new SList();
	}

};




class AVL {
public:
	AvlNode* root;

	AVL()
	{
		root = NULL;
	}

	void sameEntries(int x, AvlNode* root, int lin, string fil)
	{
		root->S->insert(x, lin, fil);
	}


	AvlNode* insert(int x, AvlNode* root, int lin, string fil)
	{
		if (root == NULL) {
			root = new AvlNode(x);
			root->file = fil;
			root->line = lin + 1;
		}

		else if (x < root->key) {
			root->left = insert(x, root->left, lin, fil);
			if (Height(root->left) - Height(root->right) == 2)
				if (x < root->left->key)
					root = RROT(root); // RR rotation
				else
					root = LRR(root); // RL rotation

		}

		else if (x > root->key) {
			root->right = insert(x, root->right, lin, fil);
			if (Height(root->right) - Height(root->left) == 2)
				if (x > root->right->key)
					root = LROT(root); // LL rotation
				else
					root = RLR(root); // LR rotation
		} /* Else X is in the tree already; we'll do nothing */

		else
		{
			sameEntries(x, root, lin, fil);				// If Same Entries	(Constructs Link List) // More entries with same key (Same Year)
		}

		root->height = Max(Height(root->left), Height(root->right)) + 1;
		return root;
	}

	int Max(int x, int y)
	{
		if (x > y)
			return x;

		return y;
	}


	int getheight(AvlNode* n)
	{
		if (n == NULL)
		{
			return 0;
		}

		return n->height;
	}

	int Height(AvlNode* P)
	{

		if (P == NULL)
			return -1;

		else

			return P->height;

	}


	int balance(AvlNode* n)
	{
		if (n == NULL)
		{
			return 0;
		}

		return Height(n->left) - Height(n->right);
	}

	AvlNode* LROT(AvlNode* n)
	{
		AvlNode* temp;
		temp = n->right;
		n->right = temp->left;
		temp->left = n;
		n->height = Max(Height(n->left), Height(n->right)) + 1;
		temp->height = Max(Height(temp->right), n->height) + 1;
		return temp;
	}

	AvlNode* RROT(AvlNode* n)
	{
		AvlNode* temp;
		temp = n->left;
		n->left = temp->right;
		temp->right = n;
		n->height = Max(Height(n->left), Height(n->right)) + 1;
		temp->height = Max(Height(temp->left), n->height) + 1;
		return temp;
	}

	AvlNode* LRR(AvlNode* n)
	{
		n->left = LROT(n->left);
		return RROT(n);
	}

	AvlNode* RLR(AvlNode* n)
	{
		n->right = RROT(n->right);
		return LROT(n);
	}

	void PreOrderTraversal(AvlNode* n)
	{
		if (n != NULL)
		{
			cout << n->key << ", ";
			PreOrderTraversal(n->left);
			PreOrderTraversal(n->right);

		}

	}


	AvlNode* minValueNode(AvlNode* node)
	{
		AvlNode* current = node;

		/* loop down to find the leftmost leaf */
		while (current->left != NULL)
			current = current->left;

		return current;
	}



	AvlNode* deleteNodeavl(AvlNode* root, int key,string n)
	{

		ofstream MyFile(n + to_string(key) + ".txt");
		MyFile << 0 << endl;
		MyFile.close();


		if (root == NULL)
			return root;

		if (key < root->key)
			root->left = deleteNodeavl(root->left, key,n);

		else if (key > root->key)
			root->right = deleteNodeavl(root->right, key,n);

		else
		{
			// node with only one child or no child 

			if ((root->left == NULL) || (root->right == NULL))
			{
				AvlNode* temp = root->left ? root->left : root->right;

				// No child case 
				if (temp == NULL)
				{
					temp = root;
					root = NULL;
				}
				else // One child case 
					*root = *temp; // Copy the contents of 
								   // the non-empty child 
				free(temp);
			}
			else
			{
				// node with two children: Get the inorder 
				// successor (smallest in the right subtree) 
				AvlNode* temp = minValueNode(root->right);

				// Copy the inorder successor's 
				// data to this node 
				root->key = temp->key;

				// Delete the inorder successor 
				root->right = deleteNodeavl(root->right, temp->key,n);
			}
		}

		// If the tree had only one node
		// then return 
		if (root == NULL)
			return root;

		// STEP 2: UPDATE HEIGHT OF THE CURRENT NODE 
		root->height = Max(Height(root->left), Height(root->right)) + 1;

		// STEP 3: GET THE BALANCE FACTOR OF 
		// THIS NODE (to check whether this 
		// node became unbalanced) 
		int balance0 = balance(root);

		// If this node becomes unbalanced, 
		// then there are 4 cases 

		// Left Left Case 
		if (balance0 > 1 && balance(root->left) >= 0)
			return RROT(root);

		// Left Right Case 
		if (balance0 > 1 && balance(root->left) < 0)
		{
			root->left = LROT(root->left);
			return RROT(root);
		}

		// Right Right Case 
		if (balance0 < -1 && balance(root->right) <= 0)
			return LROT(root);

		// Right Left Case 
		if (balance0 < -1 && balance(root->right) > 0)
		{
			root->right = RROT(root->right);
			return LROT(root);
		}

		return root;
	}

	AVL createtreeavlyear(AVL& avl,int i)
	{
	
		string a;
		string b;
		string c;
		int d, e;
		
		string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\AVLNODES_YEAR\\node-";
		ifstream file;
	
			file.open(n + to_string(i) + ".txt");
			getline(file, a);
			d = stoi(a);
	
			if (d != 0)
			{
				getline(file, c);
				getline(file, b);
	
				e = stoi(b);
	
				//avl.insert(d, e, c);
				avl.insert(d, avl.root, e, c);
	
			}
	
			// tree.root = tree.insert(tree.root, a, b, name);
			file.close();
			i++;
	
		return avl;
	
	}

	AVL createtreeavl(AVL& avl,string n)
	{
	
		string a;
		string b;
		string c;
		int d, e;
		int i = 1;
		ifstream file;
	
		do
		{
			file.open(n + to_string(i) + ".txt");
			getline(file, a);
			d = stoi(a);
	
			if (d != 0)
			{
				getline(file, c);
				getline(file, b);
	
				e = stoi(b);
	
				avl.insert(d, avl.root, e, c);
	
			}
	
			file.close();
			i++;
		} while (i <= 11000);
		return avl;
	
	}

	AVL createtrees(AVL& avl)
	{

		string a;
		string b;
		string c;
		int d, e;
		int i = 1;
		string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\AVLnodes\\node-";
		ifstream file;

		do
		{
			file.open(n + to_string(i) + ".txt");
			getline(file, a);
			d = stoi(a);

			if (d != 0)
			{
				getline(file, c);
				getline(file, b);

				e = stoi(b);

				avl.insert(d,avl.root, e, c);

			}

			// tree.root = tree.insert(tree.root, a, b, name);
			file.close();
			i++;
		} while (i < 11000);
		return avl;

	}



	void printHelperavl(AvlNode* root, string indent, bool last)
	{

		if (root != NULL) {
			cout << indent;
			if (last) {
				cout << "R----";
				indent += "     ";
			}
			else {
				cout << "L----";
				indent += "|    ";
			}


			cout << root->key << endl;
			printHelperavl(root->left, indent, false);
			printHelperavl(root->right, indent, true);
		}
	}

	void prettyPrintavl() {
		if (root) {
			printHelperavl(this->root, "", true);
		}
	}


	void create_filesavl(string n)
	{
		if (root) {

			createfilesavl(this->root, true,n);
		}
	}
	void create_filesavlyear(string n)
	{
		if (root) {

			createfilesavlyear(this->root, true, n);
		}
	}

	void createfilesavl(AvlNode* root, bool last,string n)
	{
		if (root != NULL)
		{
			ofstream MyFile(n + to_string(root->key) + ".txt");
			MyFile << root->key << endl;
			MyFile << root->file << endl;
			MyFile << root->line << endl;
		
			MyFile.close();
			if (root != NULL) {
				createfilesavl(root->left, false,n);
				createfilesavl(root->right, true,n);
			}
		}
	}
	void createfilesavlyear(AvlNode* root, bool last, string n)
	{
		if (root != NULL)
		{
			ofstream MyFile(n + to_string(root->key) + ".txt");
			root->S->print(n, root->key);
			
			MyFile.close();
			if (root != NULL) {
				createfilesavlyear(root->left, false, n);
				createfilesavlyear(root->right, true, n);
			}
		}
	}
	void searchyear(AvlNode* root,int id)
	{
		AvlNode* p = root;

		while (p != NULL)
		{
			if (id < p->key)
			{
				p = p->left;
			}
			else if (id > p->key)
			{
				p = p->right;
			}
		}
		displayyear(id);
		
	}

	AvlNode* searchTreeHelperavl(AvlNode* node, int key) {
		if (node == NULL)
			return node;
		if (key == node->key)
			return node;

		if (key < node->key)
			return searchTreeHelperavl(node->left, key);
		else if (key > node->key)
			return searchTreeHelperavl(node->right, key);
	}

	void searchTrees(int k)
	{
		AvlNode* n;
		n = searchTreeHelperavl(this->root, k);
		if(n!=NULL)
		display(n->key);
	}

	void display(int data)
	{

		string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\AVLnodes\\node-";
		ifstream MyFile(n + to_string(data) + ".txt");

			string a, b;
			getline(MyFile, b);
			getline(MyFile, a);

			vector<vector<string>> content;
			vector<string> row;
			string line, word;

			fstream file(a, ios::in);
			if (file.is_open())
			{
				while (getline(file, line))
				{
					row.clear();

					stringstream str(line);

					while (getline(str, word, ','))
						row.push_back(word);
					content.push_back(row);
				}
			}
			else
			{
				return;
			}

			int line_no;
			getline(MyFile, b);
			line_no = stoi(b);
			line_no -= 1;

			cout << "\n------------------------------------------------------------------------\n";
			cout << "                                 ID : " << data << "                             \n";
			cout << "------------------------------------------------------------------------\n\n";
			cout << "ID                         :" << content[line_no][0] << endl;
			cout << "YEAR                       :" << content[line_no][1] << endl;
			cout << "113 CAUSE NAME             :" << content[line_no][2] << endl;
			cout << "CAUSE NAME                 :" << content[line_no][3] << endl;
			cout << "STATE                      :" << content[line_no][4] << endl;
			cout << "DEATHS                     :" << content[line_no][5] << endl;
			cout << "AGE-ADJUSTED DEATH RATE    :" << content[line_no][6] << endl;
			cout << "\n------------------------------------------------------------------------\n\n";
		
	}

	void displayyear(int data)
	{

		string n = "C:\\Users\\Abdul Wasay\\source\\repos\\DS_PROJECT\\DS_PROJECT\\AVLNODES_YEAR\\node-";
		ifstream MyFile(n + to_string(data) + ".txt");

		while (!MyFile.eof())
		{
			string a, b;
			getline(MyFile, b);
			getline(MyFile, a);

			vector<vector<string>> content;
			vector<string> row;
			string line, word;

			fstream file(a, ios::in);
			if (file.is_open())
			{
				while (getline(file, line))
				{
					row.clear();

					stringstream str(line);

					while (getline(str, word, ','))
						row.push_back(word);
					content.push_back(row);
				}
			}
			else
			{
			return;
		}

			int line_no;
			getline(MyFile, b);
			line_no = stoi(b);
			line_no -= 1;

			cout << "\n------------------------------------------------------------------------\n";
			cout << "                                 ID : " << data << "                             \n";
			cout << "------------------------------------------------------------------------\n\n";
			cout << "ID                         :" << content[line_no][0] << endl;
			cout << "YEAR                       :" << content[line_no][1] << endl;
			cout << "113 CAUSE NAME             :" << content[line_no][2] << endl;
			cout << "CAUSE NAME                 :" << content[line_no][3] << endl;
			cout << "STATE                      :" << content[line_no][4] << endl;
			cout << "DEATHS                     :" << content[line_no][5] << endl;
			cout << "AGE-ADJUSTED DEATH RATE    :" << content[line_no][6] << endl;
			cout << "\n------------------------------------------------------------------------\n\n";
		}
	}

	


};