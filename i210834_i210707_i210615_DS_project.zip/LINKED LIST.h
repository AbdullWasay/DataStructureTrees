#pragma once
#include<iostream>
using namespace std;


//template < class T>
class ListNode
{
public:

	int data;									// Would be Templatized
	int line;
	string file_name;
	ListNode* next;

	ListNode()
	{
		data = 0;
		line = 0;
		file_name = "\0";
		next = NULL;
	}

	ListNode(int d)
	{
		data = d;
		file_name = "\0";
		next = NULL;
	}

	ListNode(int d, ListNode* n)
	{
		data = d;
		next = n;
		file_name = "\0";
	}

	ListNode(int d, int l, string fn)
	{
		data = d;
		line = l;
		file_name = fn;
		next = NULL;
	}

	int getData()
	{
		return data;
	}

	ListNode* getNext()
	{
		return next;
	}

};


//template < class T>
class SList
{
public:

	ListNode* head;

	SList()
	{
		head = NULL;
	}

	void insert(int a, int l_n, string fn)
	{

		if (head == NULL)
		{
			ListNode* current_ListNode = new ListNode(a, l_n, fn);
			head = current_ListNode;
		}

		else
		{
			ListNode* current_ListNode = new ListNode;
			current_ListNode = head;

			while (current_ListNode->next)
			{
				current_ListNode = current_ListNode->next;
			}

			ListNode* N = new ListNode(a, l_n, fn);
			current_ListNode->next = N;
			current_ListNode->next->next = NULL;

		}
	}

	void deleteListNode(int val)
	{
		if (head == NULL)
		{
			return;
		}
		else if (head->data == val)
		{
			ListNode* current_ListNode = new ListNode;
			current_ListNode = head;
			head = head->next;
			delete current_ListNode;
			return;
		}
		else
		{
			ListNode* current_ListNode = new ListNode();
			current_ListNode = head;
			while (current_ListNode->next)
			{
				if (current_ListNode->next->data == val)
				{
					ListNode* DeleteListNode = current_ListNode->next;
					current_ListNode->next = current_ListNode->next->next;
					delete DeleteListNode;
					return;
				}
				current_ListNode = current_ListNode->next;
			}
			return;
		}
	}

	void print(string f_n, int rk)
	{

		ListNode* current_ListNode = head;
		ofstream MyFile(f_n + to_string(rk) + ".txt", ios::app);
		
		while (current_ListNode->next!=NULL)
		{
			MyFile << current_ListNode->data << endl;			//	 YEar
			MyFile << current_ListNode->file_name << endl;		//	
			MyFile << current_ListNode->line << endl;			//	 Line 
			
			current_ListNode = current_ListNode->next;
		}

		MyFile.close();
	}

};